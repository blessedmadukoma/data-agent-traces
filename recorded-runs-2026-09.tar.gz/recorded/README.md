# Recorded runs, 23 and 24 September 2026

These are the outputs of the model runs in the preprint. With them you can check every number that comes from a model run without calling a model. See `docs/REPRODUCE.md`, Part B0, for the commands.

| Folder | Content | Preprint |
| --- | --- | --- |
| `ia/` | InfiAgent-DABench runs, gpt-oss:120b and deepseek-v4.1-flash: every cell with its code, output and the workspace listing | Table 3 |
| `qr/` | QRData run, gpt-oss:120b | Table 3 |
| `db/` | DiscoveryBench run, gpt-oss:120b | Table 3 |
| `dry/` | dry-run baseline on the recorded cells of these four runs, header-only (`h0`) and 101-line (`s100`) copies | Finding 2 |
| `llm_check/` | LLM-checker baseline, gpt-oss:120b | Finding 2 |
| `e1/` | live QRData experiment: 3,288 gpt-oss:120b runs, 822 deepseek-v4.1-flash runs in two arms plus 28 partial runs in the other arms, and the replay of every block | Table 4 |
| `receipts/` | receipt replay: the 1,000 episodes, the 250 episodes of the deepseek runs, and the results of gpt-oss:120b (2 seeds), deepseek-v4-flash:0731 and deepseek-v4.1-flash (1 seed each) | Finding 2 |

The KramaBench run is not included, because the KramaBench repository has no licence file. Its report is in `results/model-runs/`.

The records contain short excerpts of the benchmark data in cell outputs. These stay under the licences of the benchmarks: InfiAgent-DABench and QRData CC BY-NC 4.0, DiscoveryBench ODC-By, DABstep CC BY 4.0.
